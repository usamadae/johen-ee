<section id="section6" class="newsInsights bg-star-right">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="sectionHead">Explore Our <span>latest insights</span></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <h3>Press Release</h3>

                    <div class="news-content-slider">
                        <div id="news-content-slider">
                            <div class="position-relative">
                                <ul>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                </ul>


                            </div>
                            <div class="position-relative">
                                <ul>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                </ul>


                            </div>
                            <div class="position-relative">
                                <ul>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                </ul>


                            </div>
                            <div class="position-relative">
                                <ul>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                    <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s, </li>
                                </ul>


                            </div>





                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <h3>Latest News</h3>

                    <div class="news-content-slider">
                        <div id="press-content-slider">
                            <div class="position-relative">
                                <ul>


                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>

                                </ul>


                            </div>
                            <div class="position-relative">
                                <ul>


                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                </ul>


                            </div>
                            <div class="position-relative">
                                <ul>

                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                    <a class="defaultBtn mt-3" href="#">Lorem</a>
                                    <li>

                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                        Ipsum has been the industry's standard dummy text ever since the 1500s,
                                    </li>
                                </ul>


                            </div>






                        </div>
                    </div>
                </div>


                <div class="col-md-4">
                    <h3>Events</h3>

                    <div class="news-content-slider padding-custom-20">
                        <div id="events-content-slider">
                            <div class="position-relative">
                                <img class="w-100" src="assets/img/assets/event-slider.jpg" alt="Team">
                                <h4>Date: 21 may 2024</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                <a href="#">Readtext</a>

                            </div>
                            <div class="position-relative">
                                <img class="w-100" src="assets/img/assets/event-slider.jpg" alt="Team">
                                <h4>Date: 21 may 2024</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                <a href="#">Readtext</a>

                            </div>
                            <div class="position-relative">
                                <img class="w-100" src="assets/img/assets/event-slider.jpg" alt="Team">
                                <h4>Date: 21 may 2024</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                <a href="#">Readtext</a>

                            </div>
                            <div class="position-relative">
                                <img class="w-100" src="assets/img/assets/event-slider.jpg" alt="Team">
                                <h4>Date: 21 may 2024</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                                <a href="#">Readtext</a>

                            </div>






                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section>